/*
Package xdg provides an implementation of the XDG Base Directory
Specification. The specification defines a set of standard paths for storing
application files including data and configuration files. For portability and
flexibility reasons, applications should use the XDG defined locations instead
of hardcoding paths. The package also includes the locations of well known user
directories. The current implementation supports Windows, Mac OS and most
flavors of Unix.

	For more information regarding the XDG Base Directory Specification see:
	https://standards.freedesktop.org/basedir-spec/basedir-spec-latest.html

	For more information regarding the XDG user directories see:
	https://wiki.archlinux.org/index.php/XDG_user_directories
*/
package xdg

var (
	// Home contains the path of the user's home directory.
	Home string

	// DataHome defines the base directory relative to which user-specific
	// data files should be stored. This directory is defined by the
	// environment variable $XDG_DATA_HOME. If this variable is not set,
	// a default equal to $HOME/.local/share should be used.
	DataHome string

	// DataDirs defines the preference-ordered set of base directories to
	// search for data files in addition to the DataHome base directory.
	// This set of directories is defined by the environment variable
	// $XDG_DATA_DIRS. If this variable is not set, the default directories
	// to be used are /usr/local/share and /usr/share, in that order. The
	// DataHome directory is considered more important than any of the
	// directories defined by DataDirs. Therefore, user data files should be
	// written relative to the DataHome directory, if possible.
	DataDirs []string

	// ConfigHome defines the base directory relative to which user-specific
	// configuration files should be written. This directory is defined by
	// the environment variable $XDG_CONFIG_HOME. If this variable is not
	// not set, a default equal to $HOME/.config should be used.
	ConfigHome string

	// ConfigDirs defines the preference-ordered set of base directories to
	// search for configuration files in addition to the ConfigHome base
	// directory. This set of directories is defined by the environment
	// variable $XDG_CONFIG_DIRS. If this variable is not set, a default
	// equal to /etc/xdg should be used. The ConfigHome directory is
	// considered more important than any of the directories defined by
	// ConfigDirs. Therefore, user config files should be written
	// relative to the ConfigHome directory, if possible.
	ConfigDirs []string

	// CacheHome defines the base directory relative to which user-specific
	// non-essential (cached) data should be written. This directory is
	// defined by the environment variable $XDG_CACHE_HOME. If this variable
	// is not set, a default equal to $HOME/.cache should be used.
	CacheHome string

	// RuntimeDir defines the base directory relative to which user-specific
	// non-essential runtime files and other file objects (such as sockets,
	// named pipes, etc.) should be stored. This directory is defined by the
	// environment variable $XDG_RUNTIME_DIR. If this variable is not set,
	// applications should fall back to a replacement directory with similar
	// capabilities. Applications should use this directory for communication
	// and synchronization purposes and should not place larger files in it,
	// since it might reside in runtime memory and cannot necessarily be
	// swapped out to disk.
	RuntimeDir string

	// UserDirs defines the locations of well known user directories.
	UserDirs UserDirectories

	// FontDirs defines the common locations where font files are stored.
	FontDirs []string

	// ApplicationDirs defines the common locations of applications.
	ApplicationDirs []string

	// baseDirs defines the locations of base directories.
	baseDirs baseDirectories
)

// Reload refreshes base and user directories by reading the environment.
// Defaults are applied for XDG variables which are empty or not present
// in the environment.
func Reload() {
	// Initialize home directory.
	Home = homeDir()

	// Initialize base directories.
	initBaseDirs(Home)
	DataHome = baseDirs.dataHome
	DataDirs = baseDirs.data
	ConfigHome = baseDirs.configHome
	ConfigDirs = baseDirs.config
	CacheHome = baseDirs.cacheHome
	RuntimeDir = baseDirs.runtime
	FontDirs = baseDirs.fonts
	ApplicationDirs = baseDirs.applications

	// Initialize user directories.
	initUserDirs(Home)
}

// DataFile returns a suitable location for the specified data file.
// The relPath parameter must contain the name of the data file, and
// optionally, a set of parent directories (e.g. appname/app.data).
// If the specified directories do not exist, they will be created relative
// to the base data directory. On failure, an error containing the
// attempted paths is returned.
func DataFile(relPath string) (string, error) {
	return baseDirs.dataFile(relPath)
}

// ConfigFile returns a suitable location for the specified config file.
// The relPath parameter must contain the name of the config file, and
// optionally, a set of parent directories (e.g. appname/app.yaml).
// If the specified directories do not exist, they will be created relative
// to the base config directory. On failure, an error containing the
// attempted paths is returned.
func ConfigFile(relPath string) (string, error) {
	return baseDirs.configFile(relPath)
}

// CacheFile returns a suitable location for the specified cache file.
// The relPath parameter must contain the name of the cache file, and
// optionally, a set of parent directories (e.g. appname/app.cache).
// If the specified directories do not exist, they will be created relative
// to the base cache directory. On failure, an error containing the
// attempted paths is returned.
func CacheFile(relPath string) (string, error) {
	return baseDirs.cacheFile(relPath)
}

// RuntimeFile returns a suitable location for the specified runtime file.
// The relPath parameter must contain the name of the runtime file, and
// optionally, a set of parent directories (e.g. appname/app.pid).
// If the specified directories do not exist, they will be created relative
// to the base runtime directory. On failure, an error containing the
// attempted paths is returned.
func RuntimeFile(relPath string) (string, error) {
	return baseDirs.runtimeFile(relPath)
}

// SearchDataFile searches for specified file in the data search paths.
// The relPath parameter must contain the name of the data file, and
// optionally, a set of parent directories (e.g. appname/app.data). If the
// file cannot be found, an error specifying the searched paths is returned.
func SearchDataFile(relPath string) (string, error) {
	return baseDirs.searchDataFile(relPath)
}

// SearchConfigFile searches for the specified file in config search paths.
// The relPath parameter must contain the name of the config file, and
// optionally, a set of parent directories (e.g. appname/app.yaml). If the
// file cannot be found, an error specifying the searched paths is returned.
func SearchConfigFile(relPath string) (string, error) {
	return baseDirs.searchConfigFile(relPath)
}

// SearchCacheFile searches for the specified file in the cache search path.
// The relPath parameter must contain the name of the cache file, and
// optionally, a set of parent directories (e.g. appname/app.cache). If the
// file cannot be found, an error specifying the searched path is returned.
func SearchCacheFile(relPath string) (string, error) {
	return baseDirs.searchCacheFile(relPath)
}

// SearchRuntimeFile searches for the specified file in the runtime search path.
// The relPath parameter must contain the name of the runtime file, and
// optionally, a set of parent directories (e.g. appname/app.pid). If the
// file cannot be found, an error specifying the searched path is returned.
func SearchRuntimeFile(relPath string) (string, error) {
	return baseDirs.searchRuntimeFile(relPath)
}

func init() {
	Reload()
}
