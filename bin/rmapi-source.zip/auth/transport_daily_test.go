package auth

import (
	"errors"
	"net/http"
	"testing"
)

type brokenTokenStore struct{}

func (brokenTokenStore) Load() (TokenSet, error) { return TokenSet{}, errors.New("token load failed") }
func (brokenTokenStore) Save(TokenSet) error     { return nil }
func TestAuthFailureReleasesMutex(t *testing.T) {
	tr := &Transport{Auth: NewFromStore(brokenTokenStore{})}
	req, _ := http.NewRequest("GET", "https://example.invalid", nil)
	if _, err := tr.RoundTrip(req); err == nil {
		t.Fatal("expected token failure")
	}
	if !tr.mu.TryLock() {
		t.Fatal("token error left authentication locked")
	}
	tr.mu.Unlock()
	if _, err := tr.RoundTrip(req); err == nil {
		t.Fatal("expected second nonblocking token failure")
	}
}
