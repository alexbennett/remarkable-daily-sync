package config

import (
	"github.com/juruen/rmapi/model"
	"path/filepath"
	"testing"
)

func TestSaveTokensReportsFailureAndCanReplaceExisting(t *testing.T) {
	dir := t.TempDir()
	p := filepath.Join(dir, "tokens")
	if SaveTokens(filepath.Join(dir, "missing", "tokens"), model.AuthTokens{}) == nil {
		t.Fatal("write failure discarded")
	}
	for _, v := range []string{"first", "second"} {
		if err := SaveTokens(p, model.AuthTokens{DeviceToken: "device", UserToken: v}); err != nil {
			t.Fatal(err)
		}
		if got := LoadTokens(p); got.UserToken != v {
			t.Fatal("new token not persisted")
		}
	}
}
