package sync15

import (
	"encoding/json"
	"errors"
	"github.com/juruen/rmapi/archive"
	"testing"
)

func TestAppendMappingRecoveryRequiresRealMappings(t *testing.T) {
	wanted := []byte(`{"cPages":{"pages":[{"id":"a","idx":{"timestamp":"1:2","value":"ba"},"redir":{"timestamp":"1:2","value":0}}]}}`)
	var current archive.Content
	if err := json.Unmarshal(wanted, &current); err != nil {
		t.Fatal(err)
	}
	if !appendMappingPresent(wanted, current) {
		t.Fatal("exact CRDT mapping not recognized")
	}
	// Newer clock/metadata/ink does not invalidate read-only recognition.
	current.CPagesData.Pages[0].Idx.Timestamp = "1:9"
	if !appendMappingPresent(wanted, current) {
		t.Fatal("newer timestamp rejected")
	}
	current.CPagesData.Pages[0].Redir.Value = 1
	if appendMappingPresent(wanted, current) {
		t.Fatal("changed PDF redirect accepted")
	}
	current.CPagesData.Pages[0].Redir.Value = 0
	current.CPagesData.Pages[0].Deleted = &archive.CPageNumberValue{Value: 1}
	if appendMappingPresent(wanted, current) {
		t.Fatal("deleted page accepted")
	}
	if appendMappingPresent(wanted, archive.Content{}) {
		t.Fatal("missing CRDT mappings accepted")
	}
	if appendMappingPresent([]byte(`{}`), archive.Content{}) {
		t.Fatal("empty legacy mappings accepted")
	}
	if appendMappingPresent([]byte(`{"pages":[],"redirectionPageMap":[]}`), current) {
		t.Fatal("legacy arrays vacuously accepted CRDT content")
	}
	if validateAppendContent(wanted, wanted, 1, 2, 0) == nil {
		t.Fatal("unverified CRDT writes must remain disabled")
	}
}

func TestAppendContentPreservesOriginalAndUnknownFields(t *testing.T) {
	old := []byte(`{"fileType":"pdf","pageCount":1,"pages":["first"],"redirectionPageMap":[0],"custom":{"keep":true}}`)
	good := []byte(`{"fileType":"pdf","pageCount":2,"pages":["first","second"],"redirectionPageMap":[0,1],"custom":{"keep":true}}`)
	if err := validateAppendContent(old, good); err != nil {
		t.Fatal(err)
	}
	for _, bad := range []string{
		`{"fileType":"pdf","pageCount":2,"pages":["changed","second"],"redirectionPageMap":[0,1],"custom":{"keep":true}}`,
		`{"fileType":"pdf","pageCount":2,"pages":["first","second"],"redirectionPageMap":[1,0],"custom":{"keep":true}}`,
		`{"fileType":"pdf","pageCount":2,"pages":["first","first"],"redirectionPageMap":[0,1],"custom":{"keep":true}}`,
		`{"fileType":"pdf","pageCount":2,"pages":["first","second"],"redirectionPageMap":[0,1]}`,
		`{"fileType":"pdf","pageCount":2,"pages":["first","second"],"redirectionPageMap":[0,1],"custom":{"keep":true},"cPages":{}}`,
	} {
		if validateAppendContent(old, []byte(bad)) == nil {
			t.Fatalf("accepted invalid content: %s", bad)
		}
	}
}
func TestAppendRejectsConcurrentInkAndAllowsCommittedRetryWithNewInk(t *testing.T) {
	expected := map[string]string{"d.pdf": "old-pdf", "d.content": "old-content", "d/a.rm": "old-ink"}
	desired := map[string]string{"d.pdf": "new-pdf", "d.content": "new-content", "d/a.rm": "old-ink"}
	doc := &BlobDoc{Entry: Entry{DocumentID: "d"}, Files: []*Entry{{DocumentID: "d.pdf", Hash: "old-pdf"}, {DocumentID: "d.content", Hash: "old-content"}, {DocumentID: "d/a.rm", Hash: "old-ink"}}}
	if err := checkAppendFiles(doc, expected, desired); err != nil {
		t.Fatal(err)
	}
	doc.Files[2].Hash = "new-ink"
	if err := checkAppendFiles(doc, expected, desired); err == nil || errors.Is(err, errAppendApplied) {
		t.Fatal("concurrent ink must reject before append")
	}
	doc.Files[0].Hash = "new-pdf"
	doc.Files[1].Hash = "new-content"
	if err := checkAppendFiles(doc, expected, desired); !errors.Is(err, errAppendApplied) {
		t.Fatalf("committed retry must preserve new ink: %v", err)
	}
}
func TestAppendRejectsRemoteFileSetChange(t *testing.T) {
	expected := map[string]string{"d.pdf": "old", "d.content": "old-content"}
	desired := map[string]string{"d.pdf": "new", "d.content": "new-content"}
	doc := &BlobDoc{Entry: Entry{DocumentID: "d"}, Files: []*Entry{{DocumentID: "d.pdf", Hash: "old"}, {DocumentID: "d.content", Hash: "old-content"}, {DocumentID: "d/new.rm", Hash: "new-ink"}}}
	if checkAppendFiles(doc, expected, desired) == nil {
		t.Fatal("new remote annotation file was ignored")
	}
}
func TestPristineAppendRequiresNoInkAndKnownPDFCounts(t *testing.T) {
	before := []byte(`{"fileType":"pdf","pageCount":1,"pages":[],"redirectionPageMap":[]}`)
	after := []byte(`{"fileType":"pdf","pageCount":2,"originalPageCount":2,"pages":["first","second"],"redirectionPageMap":[0,1]}`)
	if err := validateAppendContent(before, after, 1, 2, 1); err != nil {
		t.Fatal(err)
	}
	if validateAppendContent(before, after, 1, 2, 0) == nil {
		t.Fatal("pristine initialization allowed with existing ink")
	}
	if validateAppendContent(before, after, 2, 3, 1) == nil {
		t.Fatal("mismatched PDF page counts accepted")
	}
	partial := []byte(`{"fileType":"pdf","pageCount":1,"pages":["first"],"redirectionPageMap":[]}`)
	if validateAppendContent(partial, after, 1, 2, 1) == nil {
		t.Fatal("partial map initialized")
	}
}
func TestUnvisitedRmapiPDFUsesParsedPhysicalCount(t *testing.T) {
	before := []byte(`{"fileType":"pdf","pageCount":0,"pages":null,"redirectionPageMap":null}`)
	after := []byte(`{"fileType":"pdf","pageCount":2,"originalPageCount":2,"pages":["first","second"],"redirectionPageMap":[0,1]}`)
	if err := validateAppendContent(before, after, 1, 2, 1); err != nil {
		t.Fatal(err)
	}
	if validateAppendContent(before, after, 1, 2, 0) == nil {
		t.Fatal("unvisited initialization allowed despite ink")
	}
	bad := []byte(`{"fileType":"pdf","pageCount":0,"originalPageCount":0,"pages":null,"redirectionPageMap":null}`)
	if validateAppendContent(bad, after, 1, 2, 1) == nil {
		t.Fatal("inconsistent explicit original count accepted")
	}
}
