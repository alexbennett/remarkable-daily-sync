package sync15

import (
	"encoding/json"
	"errors"
	"strings"
	"testing"
)

const notebookBefore = `{"fileType":"pdf","formatVersion":2,"pageCount":1,"custom":{"preserve":true},"cPages":{"original":{"timestamp":"1:1","value":1},"lastOpened":{"timestamp":"1:2","value":"p1"},"uuids":[{"first":"actor1","second":1}],"pages":[{"id":"p1","idx":{"timestamp":"1:2","value":"ba"},"redir":{"timestamp":"1:2","value":0},"template":{"timestamp":"1:2","value":"Blank"}}]}}`
const notebookAfter = `{"fileType":"pdf","formatVersion":2,"pageCount":1,"custom":{"preserve":true},"cPages":{"original":{"timestamp":"2:3","value":2},"lastOpened":{"timestamp":"1:2","value":"p1"},"uuids":[{"first":"actor1","second":1},{"first":"actor2","second":2}],"pages":[{"id":"p1","idx":{"timestamp":"1:2","value":"ba"},"redir":{"timestamp":"2:3","value":1},"template":{"timestamp":"1:2","value":"Blank"}}]}}`

func TestNotebookMiddleGrowthPreservesTabletBlankPages(t *testing.T) {
	for _, blankRedir := range []bool{false, true} {
		var before map[string]interface{}
		json.Unmarshal([]byte(notebookBefore), &before)
		cp := object(before["cPages"])
		blank := map[string]interface{}{"id": "blank", "idx": map[string]interface{}{"timestamp": "1:2", "value": "bab"}, "custom": "keep"}
		if blankRedir {
			blank["redir"] = map[string]interface{}{"timestamp": "1:2", "value": float64(-1)}
		}
		beta := map[string]interface{}{"id": "beta", "idx": map[string]interface{}{"timestamp": "1:2", "value": "bb"}, "redir": map[string]interface{}{"timestamp": "1:2", "value": float64(1)}}
		cp["pages"] = append(cp["pages"].([]interface{}), blank, beta)
		object(cp["original"])["value"] = float64(2)
		before["pageCount"] = float64(3)
		old, _ := json.Marshal(before)
		var after map[string]interface{}
		json.Unmarshal(old, &after)
		next := object(after["cPages"])
		object(next["original"])["timestamp"] = "1:3"
		object(next["original"])["value"] = float64(4)
		pages := next["pages"].([]interface{})
		object(pages[0])["redir"] = map[string]interface{}{"timestamp": "1:3", "value": float64(2)}
		next["pages"] = append(pages, map[string]interface{}{"id": "growth", "idx": map[string]interface{}{"timestamp": "1:3", "value": "baab"}, "redir": map[string]interface{}{"timestamp": "1:3", "value": float64(3)}, "template": map[string]interface{}{"timestamp": "1:3", "value": "Blank"}})
		after["pageCount"] = float64(4)
		updated, _ := json.Marshal(after)
		changed, err := validateNotebookContent(old, updated, 2, 4)
		if err != nil {
			t.Fatal(err)
		}
		if changed["blank"] || changed["beta"] || !changed["p1"] {
			t.Fatal("unrelated pages marked changed")
		}
		if _, err = notebookRemovalSet("d", []string{"d/blank.rm"}, map[string]string{"d/blank.rm": "ink"}, changed); err == nil {
			t.Fatal("unrelated blank ink deletion accepted")
		}
		object(pages[1])["deleted"] = map[string]interface{}{"timestamp": "1:3", "value": float64(1)}
		after["pageCount"] = float64(3)
		bad, _ := json.Marshal(after)
		if _, err = validateNotebookContent(old, bad, 2, 4); err == nil {
			t.Fatal("blank page deletion accepted")
		}
	}
	for _, key := range []string{"", "Ba", "ba1", strings.Repeat("a", 65)} {
		if notebookOrderingKey(key) {
			t.Fatalf("invalid key accepted %q", key)
		}
	}
}

func TestNotebookValidationAndScopedInk(t *testing.T) {
	changed, err := validateNotebookContent([]byte(notebookBefore), []byte(notebookAfter), 1, 2)
	if err != nil || !changed["p1"] {
		t.Fatalf("valid change rejected: %v", err)
	}
	expected := map[string]string{"d/p1.rm": "ink", "d/other.rm": "unprocessed"}
	if _, err = notebookRemovalSet("d", []string{"d/p1.rm"}, expected, changed); err != nil {
		t.Fatal(err)
	}
	for _, files := range [][]string{{"d/other.rm"}, {"other/p1.rm"}, {"d/p1.rm", "d/p1.rm"}, {"d/p1.rm.metadata"}, {"d/../p1.rm"}} {
		if _, err = notebookRemovalSet("d", files, expected, changed); err == nil {
			t.Fatalf("invalid deletion accepted: %v", files)
		}
	}
	for _, bad := range []string{
		strings.Replace(notebookAfter, `"preserve":true`, `"preserve":false`, 1),
		strings.ReplaceAll(notebookAfter, `"2:3"`, `"2:2"`),
		strings.ReplaceAll(notebookAfter, `"2:3"`, `"9:3"`),
		strings.Replace(notebookAfter, `"value":"ba"`, `"value":"bb"`, 1),
		strings.Replace(notebookAfter, `"value":1},"template"`, `"value":2},"template"`, 1),
		strings.Replace(notebookAfter, `"pageCount":1`, `"pageCount":2`, 1),
	} {
		if _, err = validateNotebookContent([]byte(notebookBefore), []byte(bad), 1, 2); err == nil {
			t.Fatalf("invalid content accepted: %s", bad)
		}
	}
}
func TestNotebookCASAndRecoveryNeverDeletesLaterInk(t *testing.T) {
	expected := map[string]string{"d.pdf": "old-pdf", "d.content": "old-content", "d/p1.rm": "ink", "d.metadata": "metadata"}
	desired := map[string]string{"d.pdf": "new-pdf", "d.content": "new-content", "d.metadata": "metadata"}
	doc := &BlobDoc{Entry: Entry{DocumentID: "d"}, Files: []*Entry{{DocumentID: "d.pdf", Hash: "old-pdf"}, {DocumentID: "d.content", Hash: "old-content"}, {DocumentID: "d/p1.rm", Hash: "ink"}, {DocumentID: "d.metadata", Hash: "metadata"}}}
	if err := checkNotebookFiles(doc, expected, desired); err != nil {
		t.Fatal(err)
	}
	doc.Files[2].Hash = "concurrent"
	if err := checkNotebookFiles(doc, expected, desired); err == nil || !strings.Contains(err.Error(), "notebook conflict:") {
		t.Fatal("concurrent ink not rejected")
	}
	doc.Files[0].Hash = "new-pdf"
	if err := checkNotebookFiles(doc, expected, desired); err == nil || strings.Contains(err.Error(), "notebook conflict:") {
		t.Fatal("uncertain outcome misclassified")
	}
	doc.Files[1].Hash = "new-content"
	for _, ink := range []string{"new-ink", "ink"} {
		doc.Files[2].Hash = ink
		if err := checkNotebookFiles(doc, expected, desired); !errors.Is(err, errAppendApplied) {
			t.Fatal("committed recovery failed")
		}
		if doc.Files[2].Hash != ink {
			t.Fatal("recovery modified later ink")
		}
	}
}
func TestNotebookGrowthAndShrinkPreserveOriginalRecords(t *testing.T) {
	var a map[string]interface{}
	json.Unmarshal([]byte(notebookAfter), &a)
	cp := object(a["cPages"])
	pages := cp["pages"].([]interface{})
	pages = append(pages, map[string]interface{}{"id": "p2", "idx": map[string]interface{}{"timestamp": "2:3", "value": "bb"}, "redir": map[string]interface{}{"timestamp": "2:3", "value": float64(2)}, "template": map[string]interface{}{"timestamp": "2:3", "value": "Blank"}})
	cp["pages"] = pages
	object(cp["original"])["value"] = float64(3)
	a["pageCount"] = float64(2)
	b, _ := json.Marshal(a)
	if _, err := validateNotebookContent([]byte(notebookBefore), b, 1, 3); err != nil {
		t.Fatal(err)
	}
	object(pages[0])["deleted"] = map[string]interface{}{"timestamp": "2:3", "value": float64(1)}
	a["pageCount"] = float64(1)
	b, _ = json.Marshal(a)
	if _, err := validateNotebookContent([]byte(notebookBefore), b, 1, 3); err != nil {
		t.Fatal(err)
	}
	cp["pages"] = pages[1:]
	b, _ = json.Marshal(a)
	if _, err := validateNotebookContent([]byte(notebookBefore), b, 1, 3); err == nil {
		t.Fatal("old page record removal accepted")
	}
}
