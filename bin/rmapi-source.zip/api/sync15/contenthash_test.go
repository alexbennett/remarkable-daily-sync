package sync15

import (
	"strings"
	"testing"
)

func TestContentHashCoversInkWithoutMetadataChange(t *testing.T) {
	d := &BlobDoc{Entry: Entry{DocumentID: "doc"}, Files: []*Entry{{DocumentID: "doc.pdf", Hash: strings.Repeat("0", 64)}, {DocumentID: "doc/page.rm", Hash: strings.Repeat("1", 64)}}}
	if err := d.Rehash(); err != nil {
		t.Fatal(err)
	}
	before := d.ToDocument()
	if before.ContentHash == "" {
		t.Fatal("document omitted full hash")
	}
	d.Files[1].Hash = strings.Repeat("2", 64)
	if err := d.Rehash(); err != nil {
		t.Fatal(err)
	}
	after := d.ToDocument()
	if before.ContentHash == after.ContentHash {
		t.Fatal("ink change did not change contentHash")
	}
	if before.ModifiedClient != after.ModifiedClient || before.Version != after.Version {
		t.Fatal("test changed metadata")
	}
}
