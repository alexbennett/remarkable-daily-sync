package sync15

import (
	"bufio"
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
	"os"
	"sort"
	"strconv"

	"github.com/juruen/rmapi/archive"
	"github.com/juruen/rmapi/log"
	"github.com/juruen/rmapi/transport"
	"golang.org/x/sync/errgroup"
)

const SchemaVersionV3 = "3"
const SchemaVersionV4 = "4"

const DocType = "80000000"
const FileType = "0"
const Delimiter = ':'

func FileHashAndSize(file string) ([]byte, int64, error) {
	f, err := os.Open(file)
	if err != nil {
		return nil, 0, err
	}
	defer f.Close()

	hasher := sha256.New()
	io.Copy(hasher, f)
	h := hasher.Sum(nil)
	size, err := f.Seek(0, io.SeekCurrent)
	return h, size, err

}

func parseEntry(line string) (*Entry, error) {
	entry := Entry{}
	rdr := NewFieldReader(line)
	numFields := len(rdr.fields)
	if numFields != 5 {
		return nil, fmt.Errorf("wrong number of fields %d", numFields)

	}
	var err error
	entry.Hash, err = rdr.Next()
	if err != nil {
		return nil, err
	}
	entry.Type, err = rdr.Next()
	if err != nil {
		return nil, err
	}
	entry.DocumentID, err = rdr.Next()
	if err != nil {
		return nil, err
	}
	tmp, err := rdr.Next()
	if err != nil {
		return nil, err
	}
	entry.Subfiles, err = strconv.Atoi(tmp)
	if err != nil {
		return nil, fmt.Errorf("cannot read subfiles %s %v", line, err)
	}
	tmp, err = rdr.Next()
	if err != nil {
		return nil, err
	}
	entry.Size, err = strconv.ParseInt(tmp, 10, 64)
	if err != nil {
		return nil, fmt.Errorf("cannot read size %s %v", line, err)
	}
	return &entry, nil
}

func parseSchemaV4(line string) (entriesCount int, totalSize int64, err error) {
	r := NewFieldReader(line)
	_, _ = r.Next()                //0
	_, _ = r.Next()                //.
	entriesCountStr, _ := r.Next() //count?
	totalSizeStr, _ := r.Next()    //size?

	entriesCount, err = strconv.Atoi(entriesCountStr)
	if err != nil {
		return
	}
	totalSize, err = strconv.ParseInt(totalSizeStr, 10, 64)
	if err != nil {
		return
	}

	return
}

func parseIndex(f io.Reader) ([]*Entry, string, error) {
	var entries []*Entry
	scanner := bufio.NewScanner(f)
	eof := scanner.Scan()
	if !eof {
		return nil, "", fmt.Errorf("empty index file")
	}
	schema := scanner.Text()
	expectedCount := 0
	count := 0
	var err error
	switch schema {

	case SchemaVersionV4:
		eof := scanner.Scan()
		if !eof {
			return nil, schema, fmt.Errorf("expecting a schema v4 line")
		}
		line := scanner.Text()
		expectedCount, _, err = parseSchemaV4(line)
		if err != nil {
			return nil, schema, fmt.Errorf("can't parse v4 line %v", err)
		}
		fallthrough
	case SchemaVersionV3:
		for scanner.Scan() {
			line := scanner.Text()
			if line == "" {
				log.Warning.Printf("TODO: empty line in index file, ignored")
				continue
			}
			count++
			entry, err := parseEntry(line)
			if err != nil {
				return nil, schema, fmt.Errorf("cant parse line '%s', %w", line, err)
			}

			entries = append(entries, entry)
		}
	default:
		return nil, schema, fmt.Errorf("unsupported schema %s", schema)
	}
	if schema == SchemaVersionV4 {
		if count != expectedCount {
			log.Warning.Printf("entries mismatch, expected %d, but was %d", expectedCount, count)
		}
	}

	return entries, schema, nil
}

func (t *HashTree) IndexReader() (io.Reader, error) {
	var w bytes.Buffer

	// t.SchemaVersion records the format read from the server during Mirror().
	// For writes, always emit v4 root indexes: current servers reject new
	// v3-format root docSchema uploads even when the v3 HashEntries hash
	// matches the body. Rehash() always SHA-256s the serialized output, so
	// RMAPI_FORCE_SCHEMA_VERSION=3 changes the body schema but not the hash
	// algorithm — use it only to inspect failure modes, not as a working mode.
	schemaVersion := SchemaVersionV4

	if envSchema := os.Getenv("RMAPI_FORCE_SCHEMA_VERSION"); envSchema != "" {
		log.Info.Printf("forcing schema version to %s via RMAPI_FORCE_SCHEMA_VERSION", envSchema)
		schemaVersion = envSchema
	}

	// Canonical order: the cloud validates that root index entries are sorted
	// by document ID and rejects unsorted uploads with
	// 400 {"message":"invalid root schema"} (ddvk/rmapi#75, #76 — 2026-08-17).
	//
	// Mirror() sorts, but two mutators break that order and only call Rehash():
	// Add() appends, and Remove() swaps the last element into the removed slot.
	// Sorting here — the single serialization point — keeps the emitted body and
	// the hash Rehash() derives from it consistent by construction. In-place and
	// idempotent, matching how HashEntries() canonicalizes at the doc level.
	sort.Slice(t.Docs, func(i, j int) bool { return t.Docs[i].DocumentID < t.Docs[j].DocumentID })

	w.WriteString(schemaVersion)
	w.WriteString("\n")

	if schemaVersion == SchemaVersionV4 {
		totalSize := int64(0)
		for _, d := range t.Docs {
			totalSize += d.Size
		}
		w.WriteString("0")
		w.WriteRune(Delimiter)
		w.WriteString(".")
		w.WriteRune(Delimiter)
		w.WriteString(strconv.Itoa(len(t.Docs)))
		w.WriteRune(Delimiter)
		w.WriteString(strconv.FormatInt(totalSize, 10))
		w.WriteString("\n")
	}

	for _, d := range t.Docs {
		w.WriteString(d.LineWithSchema(schemaVersion))
		w.WriteString("\n")
	}

	return bytes.NewReader(w.Bytes()), nil
}

type HashTree struct {
	Hash         string
	Generation   int64
	SchemaVersion string
	Docs         []*BlobDoc
	CacheVersion int
}

func (t *HashTree) FindDoc(id string) (*BlobDoc, error) {
	//O(n)
	for _, d := range t.Docs {
		if d.DocumentID == id {
			return d, nil
		}
	}
	return nil, fmt.Errorf("doc %s not found", id)
}

func (t *HashTree) Remove(id string) error {
	docIndex := -1
	for index, d := range t.Docs {
		if d.DocumentID == id {
			docIndex = index
			break
		}
	}
	if docIndex > -1 {
		log.Trace.Printf("Removing %s", id)
		length := len(t.Docs) - 1
		t.Docs[docIndex] = t.Docs[length]
		t.Docs = t.Docs[:length]

		t.Rehash()
		return nil
	}
	return fmt.Errorf("%s not found", id)
}

func (t *HashTree) Rehash() error {
	reader, err := t.IndexReader()
	if err != nil {
		return err
	}

	schemaBytes, err := io.ReadAll(reader)
	if err != nil {
		return err
	}

	hasher := sha256.New()
	hasher.Write(schemaBytes)
	hash := hex.EncodeToString(hasher.Sum(nil))

	log.Info.Println("New root hash: ", hash)
	t.Hash = hash
	return nil
}

// adds the extensions to filename (for the rm-file header later)
func addExt(name string, ext archive.RmExt) string {
	return name + "." + string(ext)
}

// / Mirror makes the tree look like the storage
func (t *HashTree) Mirror(r RemoteStorage, maxconcurrent int) error {
	rootHash, gen, err := r.GetRootIndex()
	if err != nil && err != transport.ErrNotFound {
		return err
	}
	if rootHash == "" && gen == 0 {
		log.Info.Println("Empty cloud")
		t.Docs = nil
		t.Generation = 0
		t.SchemaVersion = SchemaVersionV4
		log.Info.Println("defaulting to schema v4 for empty cloud")
		return nil
	}

	if rootHash == t.Hash {
		return nil
	}
	log.Info.Printf("remote root hash different")

	rootIndexReader, err := r.GetReader(rootHash, addExt("root", archive.DocSchemaExt))
	if err != nil {
		return fmt.Errorf("cannot get root hash %w", err)
	}
	defer rootIndexReader.Close()
	entries, schema, err := parseIndex(rootIndexReader)
	if err != nil {
		return fmt.Errorf("cannot parse rootIndex, %v", err)
	}

	t.SchemaVersion = schema
	log.Info.Printf("detected schema version: %s", schema)

	head := make([]*BlobDoc, 0)
	current := make(map[string]*BlobDoc)
	new := make(map[string]*Entry)

	for _, e := range entries {
		new[e.DocumentID] = e
	}
	wg, ctx := errgroup.WithContext(context.TODO())
	wg.SetLimit(maxconcurrent)

	//current documents
	for _, doc := range t.Docs {
		if entry, ok := new[doc.DocumentID]; ok {
			head = append(head, doc)
			current[doc.DocumentID] = doc

			if entry.Hash != doc.Hash {
				log.Info.Println("doc updated: ", doc.DocumentID)
				e := entry
				d := doc
				wg.Go(func() error {
					return d.Mirror(e, r)
				})
			}
		}
		select {
		case <-ctx.Done():
			goto EXIT
		default:
		}
	}

	//find new entries
	for k, newEntry := range new {
		if _, ok := current[k]; !ok {
			doc := &BlobDoc{}
			log.Trace.Println("doc new: ", k)
			head = append(head, doc)
			e := newEntry
			wg.Go(func() error {
				return doc.Mirror(e, r)
			})
		}
		select {
		case <-ctx.Done():
			goto EXIT
		default:
		}
	}
EXIT:
	err = wg.Wait()
	if err != nil {
		return fmt.Errorf("was not ok: %w", err)
	}
	sort.Slice(head, func(i, j int) bool { return head[i].DocumentID < head[j].DocumentID })
	t.Docs = head
	t.Generation = gen
	t.Hash = rootHash
	return nil
}

func BuildTree(provider RemoteStorage) (*HashTree, error) {
	tree := HashTree{}

	rootHash, gen, err := provider.GetRootIndex()

	if err != nil {
		return nil, err
	}
	tree.Hash = rootHash
	tree.Generation = gen

	rootIndex, err := provider.GetReader(rootHash, "roothash")
	if err != nil {
		return nil, err
	}

	defer rootIndex.Close()
	entries, schema, err := parseIndex(rootIndex)
	if err != nil {
		return nil, fmt.Errorf("build tree root index error %v", err)
	}

	tree.SchemaVersion = schema

	for _, e := range entries {
		f, err := provider.GetReader(e.Hash, addExt(e.DocumentID, archive.DocSchemaExt))
		if err != nil {
			return nil, fmt.Errorf("failed to read blob %s: %w", e.DocumentID, err)
		}
		defer f.Close()

		doc := &BlobDoc{}
		doc.Entry = *e

		items, _, err := parseIndex(f)
		if err != nil {
			return nil, fmt.Errorf("failed to parse index for %s: %w", e.DocumentID, err)
		}
		doc.Files = items
		for _, i := range items {
			doc.ReadMetadata(i, provider)
		}
		//don't include deleted items
		if doc.Metadata.Deleted {
			continue
		}

		tree.Docs = append(tree.Docs, doc)
	}

	return &tree, nil

}
