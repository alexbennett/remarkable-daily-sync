package sync15

// Experimental only: authorization is scoped to an explicitly selected document.
// This validates structural invariants, not undocumented firmware CRDT semantics.
import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	pdfmodel "github.com/unidoc/unipdf/v3/model"
	"os"
	"reflect"
	"strconv"
	"strings"
)

func object(v interface{}) map[string]interface{} { m, _ := v.(map[string]interface{}); return m }
func notebookOrderingKey(key string) bool {
	if len(key) < 1 || len(key) > 64 {
		return false
	}
	for _, c := range key {
		if c < 'a' || c > 'z' {
			return false
		}
	}
	return true
}
func sameExcept(a, b map[string]interface{}, keys ...string) bool {
	x, y := map[string]interface{}{}, map[string]interface{}{}
	for k, v := range a {
		x[k] = v
	}
	for k, v := range b {
		y[k] = v
	}
	for _, k := range keys {
		delete(x, k)
		delete(y, k)
	}
	return reflect.DeepEqual(x, y)
}
func clockParts(v interface{}) (int, int, bool) {
	s, ok := v.(string)
	if !ok {
		return 0, 0, false
	}
	p := strings.Split(s, ":")
	if len(p) != 2 {
		return 0, 0, false
	}
	a, e := strconv.Atoi(p[0])
	c, f := strconv.Atoi(p[1])
	return a, c, e == nil && f == nil && a >= 0 && c >= 0
}
func maxClock(v interface{}) int {
	n := 0
	switch m := v.(type) {
	case map[string]interface{}:
		for k, x := range m {
			if k == "timestamp" {
				_, c, ok := clockParts(x)
				if ok && c > n {
					n = c
				}
			}
			if c := maxClock(x); c > n {
				n = c
			}
		}
	case []interface{}:
		for _, x := range m {
			if c := maxClock(x); c > n {
				n = c
			}
		}
	}
	return n
}
func validateNotebookContent(before, after []byte, oldCount, newCount int) (map[string]bool, error) {
	var a, b map[string]interface{}
	fail := func() (map[string]bool, error) {
		return nil, errors.New("unsupported experimental notebook content change")
	}
	if json.Unmarshal(before, &a) != nil || json.Unmarshal(after, &b) != nil || a == nil || b == nil || a["fileType"] != "pdf" || b["fileType"] != "pdf" || a["formatVersion"] != float64(2) || b["formatVersion"] != float64(2) || newCount <= oldCount {
		return fail()
	}
	if !sameExcept(a, b, "cPages", "pageCount", "originalPageCount") {
		return fail()
	}
	if _, ok := a["originalPageCount"]; ok {
		if b["originalPageCount"] != float64(newCount) {
			return fail()
		}
	} else if _, ok := b["originalPageCount"]; ok {
		return fail()
	}
	ac, bc := object(a["cPages"]), object(b["cPages"])
	if ac == nil || bc == nil || !sameExcept(ac, bc, "pages", "original", "uuids") {
		return fail()
	}
	ap, ok := ac["pages"].([]interface{})
	if !ok {
		return fail()
	}
	bp, ok := bc["pages"].([]interface{})
	if !ok || len(bp) < len(ap) {
		return fail()
	}
	au, ok := ac["uuids"].([]interface{})
	if !ok {
		return fail()
	}
	bu, ok := bc["uuids"].([]interface{})
	if !ok || len(bu) < len(au) || len(bu) > len(au)+1 || !reflect.DeepEqual(au, bu[:len(au)]) {
		return fail()
	}
	authors := map[int]bool{}
	authorIDs := map[string]bool{}
	for _, v := range bu {
		u := object(v)
		id, ok := u["first"].(string)
		n, nok := u["second"].(float64)
		if !ok || !nok || id == "" || n <= 0 || n != float64(int(n)) || authors[int(n)] || authorIDs[id] {
			return fail()
		}
		authors[int(n)] = true
		authorIDs[id] = true
	}
	max := maxClock(ac)
	fresh := func(v interface{}) bool {
		m := object(v)
		actor, c, ok := clockParts(m["timestamp"])
		return ok && authors[actor] && c > max
	}
	original := object(bc["original"])
	if object(ac["original"])["value"] != float64(oldCount) {
		return fail()
	}
	if original["value"] != float64(newCount) || !fresh(original) || !sameExcept(object(ac["original"]), original, "timestamp", "value") {
		return fail()
	}
	old := map[string]map[string]interface{}{}
	oldOrder := []string{}
	blankPages := map[string]bool{}
	oldActive := 0
	for _, v := range ap {
		p := object(v)
		id, ok := p["id"].(string)
		if !ok || id == "" || old[id] != nil {
			return fail()
		}
		old[id] = p
		oldOrder = append(oldOrder, id)
		key, ok := object(p["idx"])["value"].(string)
		if !ok || !notebookOrderingKey(key) {
			return fail()
		}
		redir, ok := object(p["redir"])["value"].(float64)
		if p["redir"] == nil || (ok && redir == -1) {
			blankPages[id] = true
		} else if !ok || redir < 0 || redir >= float64(oldCount) || redir != float64(int(redir)) {
			return fail()
		}
		if object(p["deleted"])["value"] != float64(1) {
			oldActive++
		}
	}
	if a["pageCount"] != float64(oldActive) {
		return fail()
	}
	seen := map[string]bool{}
	changed := map[string]bool{}
	active := 0
	oldIndex := 0
	indices := map[string]bool{}
	for _, v := range bp {
		p := object(v)
		id, ok := p["id"].(string)
		if !ok || id == "" || strings.ContainsAny(id, "/\\") || seen[id] {
			return fail()
		}
		seen[id] = true
		idx := object(p["idx"])
		key, kok := idx["value"].(string)
		if !kok || !notebookOrderingKey(key) || indices[key] {
			return fail()
		}
		indices[key] = true
		deleted := object(p["deleted"])
		isDeleted := deleted != nil && deleted["value"] == float64(1)
		if deleted != nil && deleted["value"] != float64(0) && !isDeleted {
			return fail()
		}
		redir := object(p["redir"])
		r, rok := redir["value"].(float64)
		if !blankPages[id] && (!rok || r != float64(int(r)) || r < 0 || r >= float64(newCount)) {
			return fail()
		}
		if !isDeleted {
			active++
		}
		if previous := old[id]; previous != nil {
			if oldIndex >= len(oldOrder) || oldOrder[oldIndex] != id {
				return fail()
			}
			oldIndex++
			// Native blank pages are unrelated records: retain all fields and ink.
			if blankPages[id] {
				if !reflect.DeepEqual(previous, p) {
					return fail()
				}
				continue
			}
			if !sameExcept(previous, p, "redir", "deleted") {
				return fail()
			}
			if !reflect.DeepEqual(previous["redir"], p["redir"]) {
				if !fresh(redir) || r < float64(oldCount) || !sameExcept(object(previous["redir"]), redir, "timestamp", "value") {
					return fail()
				}
				changed[id] = true
			}
			if !reflect.DeepEqual(previous["deleted"], p["deleted"]) {
				if !isDeleted || !fresh(deleted) || !sameExcept(object(previous["deleted"]), deleted, "timestamp", "value") {
					return fail()
				}
				changed[id] = true
			}
		} else {
			if oldIndex != len(oldOrder) {
				return fail()
			}
			if isDeleted || r < float64(oldCount) || !fresh(idx) || !fresh(redir) {
				return fail()
			}
			for k := range p {
				if k != "id" && k != "idx" && k != "redir" && k != "template" {
					return fail()
				}
			}
			template := object(p["template"])
			if template["value"] != "Blank" || !fresh(template) {
				return fail()
			}
		}
	}
	if oldIndex != len(oldOrder) || b["pageCount"] != float64(active) {
		return fail()
	}
	return changed, nil
}
func notebookRemovalSet(id string, files []string, expected map[string]string, changed map[string]bool) (map[string]bool, error) {
	result := map[string]bool{}
	for _, name := range files {
		page := strings.TrimSuffix(strings.TrimPrefix(name, id+"/"), ".rm")
		if result[name] || name != id+"/"+page+".rm" || strings.ContainsAny(page, "/\\") || !changed[page] || expected[name] == "" {
			return nil, errors.New("processed ink allowlist is not an existing changed page")
		}
		result[name] = true
	}
	return result, nil
}
func checkNotebookFiles(doc *BlobDoc, expected, desired map[string]string) error {
	pdf, content := doc.DocumentID+".pdf", doc.DocumentID+".content"
	pdfDone, contentDone := false, false
	for _, f := range doc.Files {
		if f.DocumentID == pdf && f.Hash == desired[pdf] {
			pdfDone = true
		}
		if f.DocumentID == content && f.Hash == desired[content] {
			contentDone = true
		}
	}
	if desired[content] == expected[content] {
		return errors.New("notebook content must change")
	}
	// Exact changed PDF/content proves a committed transaction. Reappearing ink,
	// even identical bytes, belongs to the later state and must never be deleted.
	if pdfDone && contentDone {
		return errAppendApplied
	}
	if pdfDone || contentDone {
		return errors.New("notebook outcome uncertain: generated content found; retain recovery journal")
	}
	if len(doc.Files) != len(expected) {
		return errors.New("notebook conflict: document file set changed")
	}
	seen := map[string]bool{}
	for _, f := range doc.Files {
		if seen[f.DocumentID] || expected[f.DocumentID] == "" || expected[f.DocumentID] != f.Hash {
			return errors.New("notebook conflict: tablet changed since download")
		}
		seen[f.DocumentID] = true
	}
	return nil
}
func (ctx *ApiCtx) ReplaceNotebook(id, authorizedID, expectedArchive, pdfPath, contentPath, removePath string) error {
	if id == "" || id != authorizedID || strings.ContainsAny(id, "/\\") {
		return errors.New("experimental notebook document authorization mismatch")
	}
	expected, data, err := archiveManifest(expectedArchive)
	if err != nil {
		return err
	}
	pdfName, contentName := id+".pdf", id+".content"
	if expected[pdfName] == "" || expected[contentName] == "" {
		return errors.New("notebook baseline document mismatch")
	}
	pdf, err := os.ReadFile(pdfPath)
	if err != nil {
		return err
	}
	content, err := os.ReadFile(contentPath)
	if err != nil {
		return err
	}
	removeJSON, err := os.ReadFile(removePath)
	if err != nil {
		return err
	}
	if len(pdf) > 80*1024*1024 || len(content) > 8*1024*1024 || len(removeJSON) > 1024*1024 {
		return errors.New("notebook payload exceeds size limit")
	}
	count := func(b []byte) (int, error) {
		r, e := pdfmodel.NewPdfReader(bytes.NewReader(b))
		if e != nil {
			return 0, e
		}
		return r.GetNumPages()
	}
	oldCount, err := count(data[pdfName])
	if err != nil {
		return err
	}
	newCount, err := count(pdf)
	if err != nil {
		return err
	}
	changed, err := validateNotebookContent(data[contentName], content, oldCount, newCount)
	if err != nil {
		return err
	}
	var removals []string
	if json.Unmarshal(removeJSON, &removals) != nil {
		return errors.New("invalid processed ink allowlist")
	}
	remove, err := notebookRemovalSet(id, removals, expected, changed)
	if err != nil {
		return err
	}
	desired := map[string]string{}
	for k, v := range expected {
		if !remove[k] {
			desired[k] = v
		}
	}
	desired[pdfName] = appendHash(pdf)
	desired[contentName] = appendHash(content)
	payload := map[string][]byte{pdfName: pdf, contentName: content}
	err = Sync(ctx.blobStorage, ctx.hashTree, func(t *HashTree) error {
		doc, e := t.FindDoc(id)
		if e != nil {
			return e
		}
		if e = checkNotebookFiles(doc, expected, desired); e != nil {
			return e
		}
		retained := make([]*Entry, 0, len(doc.Files))
		for _, f := range doc.Files {
			if remove[f.DocumentID] {
				continue
			}
			if b, ok := payload[f.DocumentID]; ok {
				if e = ctx.blobStorage.UploadBlob(desired[f.DocumentID], f.DocumentID, bytes.NewReader(b)); e != nil {
					return e
				}
				f.Hash = desired[f.DocumentID]
				f.Size = int64(len(b))
			}
			retained = append(retained, f)
		}
		doc.Files = retained
		doc.Size = 0
		for _, f := range doc.Files {
			doc.Size += f.Size
		}
		if e = doc.Rehash(); e != nil {
			return e
		}
		if e = t.Rehash(); e != nil {
			return e
		}
		index, e := doc.IndexReader()
		if e != nil {
			return e
		}
		return ctx.blobStorage.UploadBlob(doc.Hash, id+".docSchema", index)
	}, true)
	if errors.Is(err, errAppendApplied) {
		return nil
	}
	if err != nil {
		return fmt.Errorf("guarded notebook update failed: %w", err)
	}
	return nil
}
