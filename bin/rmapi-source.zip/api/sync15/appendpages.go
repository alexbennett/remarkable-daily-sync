package sync15

// Codex Daily Sync extension: guarded append of PDF/content only. All original
// annotation blobs and document metadata are retained unchanged.
import (
	"archive/zip"
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/juruen/rmapi/archive"
	pdfmodel "github.com/unidoc/unipdf/v3/model"
	"io"
	"os"
	"reflect"
	"strings"
)

var errAppendApplied = errors.New("append already applied")

// Recovery is read-only. Require actual page identities/mappings, never the
// vacuously equal absent legacy arrays in a format-2 document.
func appendMappingPresent(content []byte, current archive.Content) bool {
	var wanted archive.Content
	if json.Unmarshal(content, &wanted) != nil {
		return false
	}
	if wanted.CPagesData != nil {
		if current.CPagesData == nil || len(wanted.CPagesData.Pages) == 0 || len(current.CPagesData.Pages) < len(wanted.CPagesData.Pages) {
			return false
		}
		for i, p := range wanted.CPagesData.Pages {
			q := current.CPagesData.Pages[i]
			if p.ID == "" || p.ID != q.ID || p.Idx.Value == "" || p.Idx.Value != q.Idx.Value || p.Redir == nil || q.Redir == nil || p.Redir.Value != q.Redir.Value || (p.Deleted != nil && p.Deleted.Value != 0) || (q.Deleted != nil && q.Deleted.Value != 0) {
				return false
			}
		}
		return true
	}
	return current.CPagesData == nil && len(wanted.Pages) > 0 && len(wanted.Pages) == len(wanted.RedirectionMap) && len(current.Pages) >= len(wanted.Pages) && len(current.RedirectionMap) >= len(wanted.RedirectionMap) && reflect.DeepEqual(current.Pages[:len(wanted.Pages)], wanted.Pages) && reflect.DeepEqual(current.RedirectionMap[:len(wanted.RedirectionMap)], wanted.RedirectionMap)
}

func appendHash(b []byte) string { sum := sha256.Sum256(b); return hex.EncodeToString(sum[:]) }
func archiveManifest(file string) (map[string]string, map[string][]byte, error) {
	z, err := zip.OpenReader(file)
	if err != nil {
		return nil, nil, err
	}
	defer z.Close()
	hashes := map[string]string{}
	data := map[string][]byte{}
	var total uint64
	for _, f := range z.File {
		if f.FileInfo().IsDir() {
			continue
		}
		total += f.UncompressedSize64
		if total > 160*1024*1024 || f.UncompressedSize64 > 80*1024*1024 {
			return nil, nil, errors.New("archive exceeds size limit")
		}
		if _, ok := hashes[f.Name]; ok {
			return nil, nil, errors.New("duplicate archive entry")
		}
		r, e := f.Open()
		if e != nil {
			return nil, nil, e
		}
		b, e := io.ReadAll(io.LimitReader(r, 80*1024*1024+1))
		r.Close()
		if e != nil {
			return nil, nil, e
		}
		if len(b) > 80*1024*1024 {
			return nil, nil, errors.New("archive entry exceeds size limit")
		}
		hashes[f.Name] = appendHash(b)
		data[f.Name] = b
	}
	return hashes, data, nil
}
func validateAppendContent(before, after []byte, pdfCounts ...int) error {
	var a, b map[string]interface{}
	if json.Unmarshal(before, &a) != nil || json.Unmarshal(after, &b) != nil || a == nil || b == nil {
		return errors.New("invalid content JSON")
	}
	if _, ok := a["cPages"]; ok {
		return errors.New("cPages append is unsupported; existing tablet pages preserved")
	}
	if _, ok := b["cPages"]; ok {
		return errors.New("cPages append is unsupported")
	}
	if a["fileType"] != "pdf" || b["fileType"] != "pdf" {
		return errors.New("append requires a PDF document")
	}
	ap, aok := a["pages"].([]interface{})
	bp, bok := b["pages"].([]interface{})
	ar, arok := a["redirectionPageMap"].([]interface{})
	br, brok := b["redirectionPageMap"].([]interface{})
	pristine := len(pdfCounts) == 3 && pdfCounts[2] == 1 && len(ap) == 0 && len(ar) == 0 && (aok || a["pages"] == nil) && (arok || a["redirectionPageMap"] == nil)
	if pristine {
		count := a["pageCount"]
		if count == nil {
			count = a["originalPageCount"]
		}
		// A never-opened PDF uploaded by the pinned rmapi has null page maps,
		// pageCount=0 and no originalPageCount. Its actual PDF was parsed above;
		// initialize only this ink-free shape, never reset existing page IDs.
		_, hasOriginalCount := a["originalPageCount"]
		unvisited := !hasOriginalCount && (count == nil || count == float64(0))
		if !bok || !brok || len(bp) < pdfCounts[0] || len(br) < pdfCounts[0] || (!unvisited && count != float64(pdfCounts[0])) {
			return errors.New("pristine page count does not match original PDF")
		}
		a["pageCount"] = float64(pdfCounts[0])
		ap = bp[:pdfCounts[0]]
		ar = br[:pdfCounts[0]]
		aok = true
		arok = true
		for i, v := range ar {
			if v != float64(i) {
				return errors.New("pristine PDF mappings must be sequential")
			}
		}
	}
	if !aok || !bok || !arok || !brok || len(ap) != len(ar) || len(bp) != len(br) || len(bp) <= len(ap) {
		return errors.New("append requires explicit legacy page mappings and additional pages")
	}
	if !reflect.DeepEqual(ap, bp[:len(ap)]) || !reflect.DeepEqual(ar, br[:len(ar)]) {
		return errors.New("existing page mappings must remain unchanged")
	}
	if a["pageCount"] != float64(len(ap)) || b["pageCount"] != float64(len(bp)) {
		return errors.New("pageCount must match legacy page list")
	}
	if len(pdfCounts) >= 2 {
		if pdfCounts[1] <= pdfCounts[0] || len(bp)-len(ap) != pdfCounts[1]-pdfCounts[0] {
			return errors.New("appended PDF count does not match added page mappings")
		}
		if old, ok := a["originalPageCount"]; ok && old != float64(pdfCounts[0]) {
			return errors.New("originalPageCount does not match original PDF")
		}
		if b["originalPageCount"] != float64(pdfCounts[1]) {
			return errors.New("updated originalPageCount does not match appended PDF")
		}
		for i := len(ap); i < len(br); i++ {
			if br[i] != float64(pdfCounts[0]+i-len(ap)) {
				return errors.New("new page mappings must reference appended PDF pages")
			}
		}
	}
	seen := map[string]bool{}
	for i, p := range bp {
		s, ok := p.(string)
		if !ok || s == "" || seen[s] {
			return errors.New("invalid or duplicate page ID")
		}
		seen[s] = true
		n, ok := br[i].(float64)
		if !ok || n != float64(int(n)) || n < -1 {
			return errors.New("invalid PDF page mapping")
		}
	}
	// Compare all other fields, including unknown metadata, without reserializing
	// through the lossy upstream Content struct.
	allowed := []string{"pages", "redirectionPageMap", "pageCount"}
	if len(pdfCounts) >= 2 {
		allowed = append(allowed, "originalPageCount")
	}
	for _, k := range allowed {
		delete(a, k)
		delete(b, k)
	}
	if !reflect.DeepEqual(a, b) {
		return errors.New("append may modify only pages, redirectionPageMap and pageCount")
	}
	return nil
}
func checkAppendFiles(doc *BlobDoc, expected, desired map[string]string) error {
	// A committed append remains committed if newer tablet ink was added after it.
	pdfName, contentName := doc.DocumentID+".pdf", doc.DocumentID+".content"
	pdfDone, contentDone := false, false
	for _, f := range doc.Files {
		if f.DocumentID == pdfName && f.Hash == desired[pdfName] {
			pdfDone = true
		}
		if f.DocumentID == contentName && f.Hash == desired[contentName] {
			contentDone = true
		}
	}
	if pdfDone && contentDone {
		return errAppendApplied
	}
	if len(doc.Files) != len(expected) {
		return errors.New("append conflict: document file set changed")
	}
	oldMatch, newMatch := true, true
	seen := map[string]bool{}
	for _, f := range doc.Files {
		if seen[f.DocumentID] {
			return errors.New("duplicate remote file")
		}
		seen[f.DocumentID] = true
		old, ok := expected[f.DocumentID]
		if !ok {
			return errors.New("append conflict: unexpected remote file")
		}
		if f.Hash != old {
			oldMatch = false
		}
		if f.Hash != desired[f.DocumentID] {
			newMatch = false
		}
	}
	if newMatch {
		return errAppendApplied
	}
	if !oldMatch {
		return errors.New("append conflict: tablet changed since download; synchronize again")
	}
	return nil
}
func (ctx *ApiCtx) AppendPages(docID, expectedArchive, pdfPath, contentPath string) error {
	expected, data, err := archiveManifest(expectedArchive)
	if err != nil {
		return err
	}
	pdfName, contentName := docID+".pdf", docID+".content"
	if expected[pdfName] == "" || expected[contentName] == "" {
		return errors.New("expected archive does not belong to this PDF document")
	}
	pdf, err := os.ReadFile(pdfPath)
	if err != nil {
		return err
	}
	content, err := os.ReadFile(contentPath)
	if err != nil {
		return err
	}
	if len(pdf) > 80*1024*1024 || !bytes.HasPrefix(pdf, []byte("%PDF-")) || len(content) > 8*1024*1024 {
		return errors.New("invalid or oversized append payload")
	}
	oldReader, err := pdfmodel.NewPdfReader(bytes.NewReader(data[pdfName]))
	if err != nil {
		return err
	}
	oldCount, err := oldReader.GetNumPages()
	if err != nil {
		return err
	}
	newReader, err := pdfmodel.NewPdfReader(bytes.NewReader(pdf))
	if err != nil {
		return err
	}
	newCount, err := newReader.GetNumPages()
	if err != nil {
		return err
	}
	pristine := 1
	for name := range expected {
		if strings.HasSuffix(name, ".rm") {
			pristine = 0
		}
	}
	if err = validateAppendContent(data[contentName], content, oldCount, newCount, pristine); err != nil {
		return err
	}
	desired := map[string]string{}
	for k, v := range expected {
		desired[k] = v
	}
	desired[pdfName] = appendHash(pdf)
	desired[contentName] = appendHash(content)
	payload := map[string][]byte{pdfName: pdf, contentName: content}
	err = Sync(ctx.blobStorage, ctx.hashTree, func(t *HashTree) error {
		doc, e := t.FindDoc(docID)
		if e != nil {
			return e
		}
		// The tablet may have edited content metadata or appended more pages after
		// our successful CAS. Recognize our PDF and page-ID prefix without writing.
		desiredPDF := false
		for _, f := range doc.Files {
			if f.DocumentID == pdfName && f.Hash == desired[pdfName] {
				desiredPDF = true
			}
		}
		if desiredPDF {
			if appendMappingPresent(content, doc.Content) {
				return errAppendApplied
			}
			// Matching generated PDF proves a possible committed transaction. Never
			// call this a pre-write conflict: the caller must retain its journal.
			// Exact content hashes are handled by checkAppendFiles below even when
			// this in-memory Content struct has not been refreshed from the blob.
			if e = checkAppendFiles(doc, expected, desired); errors.Is(e, errAppendApplied) {
				return e
			}
			return errors.New("append outcome uncertain: appended PDF exists but page mapping changed; retain recovery journal")
		}
		if e = checkAppendFiles(doc, expected, desired); e != nil {
			return e
		}
		for _, f := range doc.Files {
			if b, ok := payload[f.DocumentID]; ok {
				if e = ctx.blobStorage.UploadBlob(desired[f.DocumentID], f.DocumentID, bytes.NewReader(b)); e != nil {
					return e
				}
				f.Hash = desired[f.DocumentID]
				f.Size = int64(len(b))
			}
		}
		doc.Size = 0
		for _, f := range doc.Files {
			doc.Size += f.Size
		}
		if e = doc.Rehash(); e != nil {
			return e
		}
		if e = t.Rehash(); e != nil {
			return e
		}
		index, e := doc.IndexReader()
		if e != nil {
			return e
		}
		return ctx.blobStorage.UploadBlob(doc.Hash, docID+".docSchema", index)
	}, true)
	if errors.Is(err, errAppendApplied) {
		return nil
	}
	if err != nil {
		return fmt.Errorf("guarded append failed: %w", err)
	}
	return nil
}
