package api

import (
	"encoding/base64"
	"fmt"
	"testing"
	"time"
)

func TestReuseUnexpiredUserToken(t *testing.T) {
	token := func(exp int64) string {
		return "eyJhbGciOiJIUzI1NiJ9." + base64.RawURLEncoding.EncodeToString([]byte(fmt.Sprintf(`{"exp":%d}`, exp))) + ".signature"
	}
	if shouldRefreshUserToken(token(time.Now().Unix()+3600), false) {
		t.Fatal("valid token must be reused")
	}
	if !shouldRefreshUserToken(token(time.Now().Unix()-3600), false) || !shouldRefreshUserToken("broken", false) || !shouldRefreshUserToken(token(time.Now().Unix()+3600), true) {
		t.Fatal("invalid/expired/explicit unauthorized token must refresh")
	}
}
