package shell

import (
	"errors"
	"flag"
	"github.com/abiosoft/ishell"
	"io"
	"strings"
)

func replaceNotebookCmd(ctx *ShellCtxt) *ishell.Cmd {
	return &ishell.Cmd{Name: "replace-notebook", Help: "experimental document-scoped notebook update", Func: func(c *ishell.Context) {
		flags := flag.NewFlagSet("replace-notebook", flag.ContinueOnError)
		flags.SetOutput(io.Discard)
		id := flags.String("id", "", "document id")
		authorized := flags.String("authorized-document-id", "", "explicitly authorized experimental document")
		expected := flags.String("expected-archive", "", "baseline archive")
		pdf := flags.String("pdf", "", "updated PDF")
		content := flags.String("content", "", "updated content")
		remove := flags.String("remove-manifest", "", "processed ink names JSON")
		if err := flags.Parse(c.Args); err != nil {
			c.Err(err)
			return
		}
		if *id == "" || *id != *authorized || *expected == "" || *pdf == "" || *content == "" || *remove == "" || len(flags.Args()) != 0 {
			c.Err(errors.New("experimental notebook arguments and matching authorization are required"))
			return
		}
		helper, ok := ctx.api.(interface {
			ReplaceNotebook(string, string, string, string, string, string) error
		})
		if !ok {
			c.Err(errors.New("experimental notebook update unavailable"))
			return
		}
		if err := helper.ReplaceNotebook(*id, *authorized, *expected, *pdf, *content, *remove); err != nil {
			if strings.Contains(err.Error(), "notebook conflict:") {
				c.Println("NOTEBOOK_CONFLICT")
				return
			}
			c.Err(err)
			return
		}
		c.Println("NOTEBOOK_OK")
	}}
}
