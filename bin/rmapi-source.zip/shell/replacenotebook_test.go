package shell

import (
	"github.com/abiosoft/ishell"
	"github.com/juruen/rmapi/api"
	"reflect"
	"testing"
)

type notebookTestAPI struct {
	api.ApiCtx
	received []string
}

func (a *notebookTestAPI) ReplaceNotebook(id, authorized, expected, pdf, content, remove string) error {
	a.received = []string{id, authorized, expected, pdf, content, remove}
	return nil
}
func TestNotebookCommandArgumentGate(t *testing.T) {
	for _, authorized := range []string{"doc", "other", ""} {
		a := &notebookTestAPI{}
		sh := ishell.New()
		sh.AddCmd(replaceNotebookCmd(&ShellCtxt{api: a}))
		err := sh.Process("replace-notebook", "--id", "doc", "--authorized-document-id", authorized, "--expected-archive", "expected file.rmdoc", "--pdf", "updated.pdf", "--content", "updated.content", "--remove-manifest", "processed ink.json")
		if authorized == "doc" {
			if err != nil {
				t.Fatal(err)
			}
			if !reflect.DeepEqual(a.received, []string{"doc", "doc", "expected file.rmdoc", "updated.pdf", "updated.content", "processed ink.json"}) {
				t.Fatalf("wrong args %v", a.received)
			}
		} else if a.received != nil {
			t.Fatal("unauthorized document reached helper")
		}
	}
}
