package shell

import (
	"errors"
	"flag"
	"github.com/abiosoft/ishell"
	"io"
	"strings"
)

func appendPagesCmd(ctx *ShellCtxt) *ishell.Cmd {
	return &ishell.Cmd{Name: "append-pages", Help: "guarded append of PDF pages", Func: func(c *ishell.Context) {
		// The pinned ancient pflag requires --name=value for long string flags.
		// Standard flag accepts both forms, including execFile's separate argv.
		flags := flag.NewFlagSet("append-pages", flag.ContinueOnError)
		flags.SetOutput(io.Discard)
		id := flags.String("id", "", "document id")
		expected := flags.String("expected-archive", "", "expected downloaded archive")
		pdf := flags.String("pdf", "", "combined PDF")
		content := flags.String("content", "", "appended legacy content JSON")
		if err := flags.Parse(c.Args); err != nil {
			c.Err(err)
			return
		}
		if *id == "" || *expected == "" || *pdf == "" || *content == "" || len(flags.Args()) != 0 {
			c.Err(errors.New("all append arguments are required"))
			return
		}
		helper, ok := ctx.api.(interface {
			AppendPages(string, string, string, string) error
		})
		if !ok {
			c.Err(errors.New("guarded append unavailable"))
			return
		}
		if err := helper.AppendPages(*id, *expected, *pdf, *content); err != nil {
			if strings.Contains(err.Error(), "append conflict:") {
				c.Println("APPEND_CONFLICT")
				return
			}
			c.Err(err)
			return
		}
		c.Println("APPEND_OK")
	}}
}
