package shell

import (
	"github.com/abiosoft/ishell"
	"github.com/juruen/rmapi/api"
	"reflect"
	"testing"
)

type appendTestAPI struct {
	api.ApiCtx
	received []string
}

func (a *appendTestAPI) AppendPages(id, expected, pdf, content string) error {
	a.received = []string{id, expected, pdf, content}
	return nil
}
func TestAppendCommandSeparateArgv(t *testing.T) {
	for _, args := range [][]string{
		{"append-pages", "--id", "document-id", "--expected-archive", "expected file.rmdoc", "--pdf", "combined.pdf", "--content", "appended.content"},
		{"append-pages", "--id=document-id", "--expected-archive=expected file.rmdoc", "--pdf=combined.pdf", "--content=appended.content"},
	} {
		a := &appendTestAPI{}
		shell := ishell.New()
		shell.AddCmd(appendPagesCmd(&ShellCtxt{api: a}))
		if err := shell.Process(args...); err != nil {
			t.Fatal(err)
		}
		if !reflect.DeepEqual(a.received, []string{"document-id", "expected file.rmdoc", "combined.pdf", "appended.content"}) {
			t.Fatalf("wrong argv: %v", a.received)
		}
	}
}
