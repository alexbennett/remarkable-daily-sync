package shell

import (
	"encoding/json"
	"github.com/juruen/rmapi/model"
	"strings"
	"testing"
)

func TestContentHashIncludedInJSON(t *testing.T) {
	node := model.CreateNode(model.Document{ID: "doc", ContentHash: strings.Repeat("a", 64)})
	b, err := json.Marshal(nodeToJSON(&node))
	if err != nil {
		t.Fatal(err)
	}
	var out map[string]interface{}
	json.Unmarshal(b, &out)
	if out["contentHash"] != strings.Repeat("a", 64) {
		t.Fatal("JSON omitted contentHash")
	}
}
