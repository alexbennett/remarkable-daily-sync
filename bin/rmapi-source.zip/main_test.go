package main

import (
	"errors"
	"fmt"
	"github.com/juruen/rmapi/transport"
	"testing"
)

func TestAuthenticationRetryOnlyFor401(t *testing.T) {
	if !shouldRetryAuthentication(fmt.Errorf("tree failed: %w", transport.ErrUnauthorized)) {
		t.Fatal("wrapped 401 should refresh")
	}
	for _, err := range []error{errors.New("timeout"), errors.New("schema error"), &transport.RateLimitError{}, transport.ErrWrongGeneration} {
		if shouldRetryAuthentication(err) {
			t.Fatalf("unexpected token refresh: %v", err)
		}
	}
}
