package main

import (
	"errors"
	"flag"
	"fmt"
	"os"

	"github.com/juruen/rmapi/api"
	"github.com/juruen/rmapi/config"
	"github.com/juruen/rmapi/log"
	"github.com/juruen/rmapi/shell"
	"github.com/juruen/rmapi/transport"
	"github.com/juruen/rmapi/version"
)

const AUTH_RETRIES = 3

func shouldRetryAuthentication(err error) bool { return errors.Is(err, transport.ErrUnauthorized) }

func parseOfflineCommands(cmd []string) bool {
	if len(cmd) == 0 {
		return false
	}

	switch cmd[0] {
	case "reset":
		configFile, err := config.ConfigPath()
		if err != nil {
			log.Error.Fatalln(err)
		}
		if err := os.Remove(configFile); err != nil {
			log.Error.Fatalln(err)
		}
		return true
	case "version":
		fmt.Println(version.Version)
		return true
	}
	return false
}

func main() {
	ni := flag.Bool("ni", false, "not interactive (prevents asking for code)")
	jsonOutput := flag.Bool("json", false, "output in JSON format")
	flag.Usage = func() {
		fmt.Println(`
  help		detailed commands, but the user needs to be logged in

Offline Commands:
  version	prints the version
  reset		removes the config file `)

		flag.PrintDefaults()
	}
	flag.Parse()
	otherFlags := flag.Args()
	if parseOfflineCommands(otherFlags) {
		return
	}

	var ctx api.ApiCtx
	var err error
	var userInfo *api.UserInfo
	reAuth := false

	for i := 0; i < AUTH_RETRIES; i++ {
		authCtx := api.AuthHttpCtx(reAuth, *ni)

		userInfo, err = api.ParseToken(authCtx.Tokens.UserToken)
		if err != nil {
			log.Trace.Println(err)
			reAuth = true
			continue
		}

		ctx, err = api.CreateApiCtx(authCtx, userInfo.SyncVersion)
		if err != nil {
			log.Trace.Println(err)
			// Network, rate-limit, schema and storage errors cannot be repaired
			// by minting another user token. Refresh only for a real HTTP 401.
			if !shouldRetryAuthentication(err) {
				break
			}
			reAuth = true
		} else {
			break
		}
	}

	if err != nil {
		log.Error.Fatal("failed to build documents tree, last error: ", err)
	}

	err = shell.RunShell(ctx, userInfo, otherFlags, *jsonOutput)

	if err != nil {
		log.Error.Println("Error: ", err)

		os.Exit(1)
	}
}
