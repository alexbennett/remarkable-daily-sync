package transport

import (
	"fmt"
	"math"
	"net/http"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"
)

type RateLimitError struct{ RetryAfter time.Duration }

func (e *RateLimitError) Error() string {
	return fmt.Sprintf("HTTP 429: cloud cooldown; retry after %d seconds", int64(math.Ceil(e.RetryAfter.Seconds())))
}

var cooldownMu sync.Mutex
var cooldowns = map[string]time.Time{}

func cooldownKey() string { return os.Getenv("RMAPI_CONFIG") }
func retryDelay(value string, now time.Time) time.Duration {
	delay := time.Minute
	if seconds, err := strconv.ParseInt(strings.TrimSpace(value), 10, 64); err == nil && seconds > 0 && seconds < int64((1<<63-1)/time.Second) {
		if candidate := time.Duration(seconds) * time.Second; candidate > delay {
			delay = candidate
		}
	} else if date, err := http.ParseTime(value); err == nil && date.Sub(now) > delay {
		delay = date.Sub(now)
	}
	return delay
}
func storedCooldown(key string) time.Time {
	until := cooldowns[key]
	if key != "" {
		if b, err := os.ReadFile(key + ".rate-limit"); err == nil {
			if parsed, err := time.Parse(time.RFC3339Nano, string(b)); err == nil && parsed.After(until) {
				until = parsed
			}
		}
	}
	return until
}
func currentCooldown() error {
	cooldownMu.Lock()
	defer cooldownMu.Unlock()
	remaining := time.Until(storedCooldown(cooldownKey()))
	if remaining > 0 {
		return &RateLimitError{remaining}
	}
	return nil
}
func recordCooldown(value string) error {
	cooldownMu.Lock()
	defer cooldownMu.Unlock()
	now := time.Now()
	key := cooldownKey()
	until := now.Add(retryDelay(value, now))
	if stored := storedCooldown(key); stored.After(until) {
		until = stored
	}
	cooldowns[key] = until
	if key != "" {
		_ = os.WriteFile(key+".rate-limit", []byte(until.Format(time.RFC3339Nano)), 0600)
	}
	return &RateLimitError{until.Sub(now)}
}
