package transport

import (
	"errors"
	"github.com/juruen/rmapi/model"
	"io"
	"net/http"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

type fakeRoundTrip func(*http.Request) (*http.Response, error)

func (f fakeRoundTrip) RoundTrip(r *http.Request) (*http.Response, error) { return f(r) }
func TestRateLimitStopsFurtherRequestsAndPersistsCooldown(t *testing.T) {
	t.Setenv("RMAPI_CONFIG", filepath.Join(t.TempDir(), "rmapi.conf"))
	count := 0
	ctx := CreateHttpClientCtx(model.AuthTokens{})
	ctx.Client = &http.Client{Transport: fakeRoundTrip(func(*http.Request) (*http.Response, error) {
		count++
		return &http.Response{StatusCode: 429, Header: http.Header{"Retry-After": []string{"1800"}}, Body: io.NopCloser(strings.NewReader(""))}, nil
	})}
	response, err := ctx.Request(UserBearer, "GET", "https://example.invalid", nil, nil, 0)
	if response != nil {
		response.Body.Close()
	}
	var limited *RateLimitError
	if !errors.As(err, &limited) || limited.RetryAfter < 29*time.Minute {
		t.Fatalf("bad rate limit: %v", err)
	}
	cooldowns = map[string]time.Time{} // Simulate a new process, retaining sidecar only.
	_, err = ctx.Request(DeviceBearer, "POST", "https://example.invalid/token/user/new", nil, nil, 0)
	if !errors.As(err, &limited) || count != 1 {
		t.Fatalf("cooldown allowed network/auth request: count=%d err=%v", count, err)
	}
}
func TestRetryAfterMinimumAndHTTPDate(t *testing.T) {
	now := time.Now()
	if retryDelay("2", now) != time.Minute || retryDelay("invalid", now) != time.Minute || retryDelay("", now) != time.Minute {
		t.Fatal("minimum cooldown")
	}
	if retryDelay(now.Add(time.Hour).UTC().Format(http.TimeFormat), now) < 59*time.Minute {
		t.Fatal("HTTP date ignored")
	}
}
